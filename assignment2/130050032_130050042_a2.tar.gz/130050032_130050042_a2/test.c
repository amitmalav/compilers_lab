int ___hi2func__() {
    int x;
    return x;
}

int ___hi5func__() {
    int x, y;
    int a[2];
    for(x = 0; x < 10; x++){
    	x = x + 1;a[2] = x;
    	a[2] = &x;
    	z = a[2].x;
    	y = a[1]->x;
    	y = *x;

    }
    	
}