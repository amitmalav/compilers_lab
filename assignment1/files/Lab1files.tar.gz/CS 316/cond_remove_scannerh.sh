if [ -e Scanner.h ] 
  then rm Scanner.h;
fi