															Assignment 2 Part 2

_____________________________________________________________________________________________________________________________________________________

Symbol Table Format:

Struct:			Name	struct		SizeofStruct
Struct Member:	Name	type		size 			offset(starting from 0 to negative)

Function:		Name	ReturnType	-1
Function Para:	Name	Type		size 			Offset(starting from 0 to positive)
Local vars:		Name	Type 		size 			Offset(starting from 0 to negative)

_____________________________________________________________________________________________________________________________________________________


Running Instructions:
make


_____________________________________________________________________________________________________________________________________________________


Files Included:
ast.cpp
ast.h
lex.l
main.cc
makefile
parse.y
readme.txt
st.cpp
st.h
test.c
